from django.shortcuts import render, redirect
from .forms import EmailForm

def email_collector(request):
    if request.method == 'POST':
        form = EmailForm(request.POST)
        if form.is_valid():
            form.save()  # Save the email to the database
            return redirect('success')  # Redirect after successful submission
    else:
        form = EmailForm()
    return render(request, 'index.html', {'form': form})

def success(request):
    return render(request, 'success.html')
