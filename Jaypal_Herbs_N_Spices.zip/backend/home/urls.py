from django.urls import path
from .views import email_collector, success

urlpatterns = [
    path('', email_collector, name='email_collector'),
    path('success/', success, name='success'),
]
