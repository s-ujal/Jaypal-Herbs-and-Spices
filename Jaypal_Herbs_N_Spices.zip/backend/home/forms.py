from django import forms
from .models import CustomerEmail

class EmailForm(forms.ModelForm):
    class Meta:
        model = CustomerEmail
        fields = ['email']
